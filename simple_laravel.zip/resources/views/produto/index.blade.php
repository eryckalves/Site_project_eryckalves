@extends('layouts.app')

@section('content')

<h3> Produto </h3>

@endsection