<?php $__env->startSection('content'); ?>


        <!--Section: about-->
        <section id="about" class="py-5 bg-light">

            <!-- Container -->
            <div class="container">
                <!-- Section heading -->
                <h2 class="h1 font-weight-bold text-center mb-5">Tecnologias Utilizadas</h2>
                <!-- Section desc -->
                <p class="lead text-center">A imaginação é mais importante 
                    que a ciência, porque a ciência é limitada, ao passo que a imaginação 
                    abrange o mundo inteiro. </P>
                    <p class="lead text-center mx-auto mb-5"> "Albert Einstein"</p>

                
                <!-- row -->
                <div class="row mb-4 pb-1">

                    <!-- column -->
                    <div class="col-sm-7 ">

                        <!-- row -->
                        <div class="row mb-3">

                            <!--column -->
                            <div class="col-1 text-right">
                                <i class="fab fa-laravel"></i>
                            </div>
                            <!-- END column -->

                            <!-- column -->
                            <div class="col-xl-10 col-md-11 col-10" style="min-height:100px;">
                                <h5 class="font-weight-bold mb-3">Laravel</h5>
                                <p class="text-secondary">Lorem ipsum dolor sit amet, consectetur adipisicing elit enim ad
                                    minima veniam, quis nostrum exercitationem ullam.</p>
                            </div>
                            <!-- END column -->

                        </div>
                        <!-- END row -->

                        <!--row-->
                        <div class="row">

                            <!-- column -->
                            <div class="col-1 text-right">
                                <i class="fab fa-bootstrap"></i>
                            </div>
                            <!-- END column -->

                            <!-- column -->
                            <div class="col-xl-10 col-md-11 col-10" style="min-height:100px;">
                                <h5 class="font-weight-bold mb-3">Bootstrap</h5>
                                <p class="text-secondary">Lorem ipsum dolor sit amet, consectetur adipisicing elit enim
                                    ad minima veniam, quis nostrum exercitationem ullam. Reprehenderit maiores aperiam
                                    assumenda deleniti hic.</p>
                            </div>
                            <!-- END column -->

                        </div>
                        <!--END row-->

                        <!--row-->
                        <div class="row">

                            <!-- column -->
                            <div class="col-1 text-right">
                                <i class="fab fa-js"></i>
                            </div>
                            <!-- END column -->

                            <!-- column -->
                            <div class="col-xl-10 col-md-11 col-10" style="min-height:100px;">
                                <h5 class="font-weight-bold mb-3">JavaScript</h5>
                                <p class="text-secondary">Lorem ipsum dolor sit amet.</p>
                            </div>
                            <!-- END column -->

                        </div>
                        <!--END row-->

                    </div>
                    <!--END column-->

                    <!-- column -->
                    <div class="col-5 col-md-5 text-lg-right pr-4">
                        <img class="img-fluid" src="<?php echo e(asset('storage/images/codes.jpg')); ?>" alt="Sample image">
                    </div>
                    <!-- END column -->

            
                </div>
                <!-- END row -->


                <!-- row -->
                <div class="row">

                    <!-- column -->
                    <div class="col-7 col-md-7 text-center text-lg-left">
                        <img class="img-fluid" src="<?php echo e(asset('storage/images/imagetest.jpg')); ?>" alt="Sample image">
                    </div>
                    <!-- END column -->

                    <!-- column -->
                    <div class="col-5 pl-4" style="padding-right:0;">

                        <!-- row -->
                        <div class="row mb-3">

                            <!--column -->
                            <div class="col-1 text-right">
                                <i class="fas fa-code"></i>
                            </div>
                            <!-- end column -->

                            <!-- column -->
                            <div class="col-xl-10 col-md-11 col-10" style="min-height:100px;">
                                <h5 class="font-weight-bold mb-3">Code</h5>
                                <p class="text-secondary">Lorem ipsum dolor sit amet, consectetur adipisicing elit enim ad
                                    minima veniam, quis nostrum exercitationem ullam.</p>
                            </div>
                            <!-- END column -->

                        </div>
                        <!-- END row -->

                        <!-- row -->
                        <div class="row mb-3">

                            <!-- column -->
                            <div class="col-1 text-right">
                                <i class="fas fa-laptop-code"></i>
                            </div>
                            <!-- END column -->

                            <!-- column -->
                            <div class="col-xl-10 col-md-11 col-10" style="min-height:100px;">
                                <h5 class="font-weight-bold mb-3">Technology</h5>
                                <p class="text-secondary">Lorem ipsum dolor sit amet

                                </p>
                            </div>
                            <!-- END column -->

                        </div>
                        <!-- END row -->

                        <!--row-->
                        <div class="row">

                            <!-- column -->
                            <div class="col-1 text-right">
                                <i class="fas fa-pencil-ruler"></i>
                            </div>
                            <!-- END column -->

                            <!-- column -->
                            <div class="col-xl-10 col-md-11 col-10" style="min-height:100px;">
                                <h5 class="font-weight-bold mb-3">Design</h5>
                                <p class="text-secondary">Lorem ipsum dolor sit amet, consectetur adipisicing elit enim
                                    ad minima veniam, quis nostrum exercitationem ullam. Reprehenderit maiores aperiam
                                    assumenda deleniti hic.</p>
                            </div>
                            <!-- END column -->

                        </div>
                        <!--END row-->

                    </div>
                    <!--END column-->

                </div>
                <!-- END row -->

            </div>
            <!-- END Container -->

        </section>
        <!-- END Section: about-->

        <!-- Section: team -->
        <section id="team" class="py-5">

            <!--Container -->
            <div class="container text-center">

                <!-- row -->
                <div class="row mb-4">
                    <div class="col team-h1">
                    <h2 class="h1 font-weight-bold text-center mb-5">Nosso Time</h2>
                    <p class="lead text-center">Cada um é responsável por uma tarefa
                        , mas a equipe trabalhando em sinergia fica completa.</p>
                    <p class="lead text-center mx-auto mb-5"> "Jose Lourenço Claudio Junior"</p>
                    </div>
                </div>
                <!-- END row -->

                <!-- row -->
                <div class="row justify-content-between">

                    <!-- col card -->
                    <div class="col-lg-3 col-md-6 card-h3">

                        <!-- card-->
                        <div class="card pb-5 mb-5">
                            <div class="card-body">
                                <img src="<?php echo e(asset('storage/images/coffee-machine.png')); ?>" 
                                class="img-fluid rounded-circle mb-3 w-50" >
                                <h3>Máquina de Cáfe</h3>
                                <h5>Coffee Leader</h5>
                                <p>Lorem ipsum dolor sit amet. 
                                </p>

                                <!-- d-flex flex-row -->
                                <div class="d-flex flex-row">
                                    <div class="p-4">
                                        <a href="">
                                            <i class="fab fa-facebook"></i>
                                        </a>
                                    </div>
                                    <div class="p-4">
                                        <a href="">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </div>
                                    <div class="p-4">
                                        <a href="">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </div>
                                </div>
                                <!-- END d-flex flex-row -->

                            </div>
                        </div>
                        <!-- END card-->
                        
                    </div>
                    <!-- END col card -->

                    <!-- col card -->
                    <div class="col-lg-3 col-md-6 card-h3">

                        <!-- card-->
                        <div class="card card pb-5 mb-5" >
                            <div class="card-body">
                                <img src="<?php echo e(asset('storage/images/eryckalves.jpg')); ?>" 
                                class="img-fluid rounded-circle mb-3 w-50" >
                                <h3>Eryck Vaz Alves</h3>
                                <h5>Fullstack (Faz Tudo)</h5>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                                </p>

                                <!-- d-flex flex-row -->
                                <div class="d-flex flex-row">
                                    <div class="p-4">
                                        <a href="">
                                            <i class="fab fa-facebook"></i>
                                        </a>
                                    </div>
                                    <div class="p-4">
                                        <a href="">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </div>
                                    <div class="p-4">
                                        <a href="">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </div>
                                </div>
                                <!-- END d-flex flex-row -->

                            </div>
                        </div>
                        <!-- END card-->
                        
                    </div>
                    <!-- END col card -->

                    <!-- col card -->
                    <div class="col-lg-3 col-md-6 card-h3">

                        <!-- card-->
                        <div class="card card pb-5 mb-5" >
                            <div class="card-body">
                                <img src="<?php echo e(asset('storage/images/computer.png')); ?>" 
                                class="img-fluid rounded-circle mb-3 w-50" >
                                <h3>Computer</h3>
                                <h5>Intelligente Artificial</h5>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                                    Proin vestibulum egestas nisl, et tempus nibh luctus ut. 
                                </p>

                                <!-- d-flex flex-row -->
                                <div class="d-flex flex-row">
                                    <div class="p-4">
                                        <a href="">
                                            <i class="fab fa-facebook"></i>
                                        </a>
                                    </div>
                                    <div class="p-4">
                                        <a href="">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </div>
                                    <div class="p-4">
                                        <a href="">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </div>
                                </div>
                                <!-- END d-flex flex-row -->

                            </div>
                        </div>
                        <!-- END card-->
                        
                    </div>
                    <!-- END col card -->

                </div>
                <!-- END row -->

            </div>
            <!-- END Container -->

        </section>
        <!-- END Section: team -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projpag\simple_laravel\resources\views/sobre/index.blade.php ENDPATH**/ ?>