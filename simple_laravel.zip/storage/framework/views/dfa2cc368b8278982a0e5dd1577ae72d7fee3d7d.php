<?php $__env->startSection('content'); ?>
<div class="container">

    <form action="/galeria" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>

        <div class="row">
                <div class="col-8 offset-2">
                    <div class="row pl-3">
                        <h1>Adicionar Nova Imagem</h1>
                    </div>
                    <div class="form-group row pl-2">
                        <label for="Caption" class="col-4 col-form-label">Incluir Comentários</label>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input id="caption"
                                type="text" 
                                class="form-control <?php $__errorArgs = ['Caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="caption"
                                value="<?php echo e(old('Caption')); ?>" 
                                required autocomplete="Caption" 
                                autofocus>
                        </div>
                        <?php $__errorArgs = ['Caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($caption); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="row pl-2 pt-2">
                        <label for="image" class="col-4 col-form-label">Incluir imagem</label>
                        <input type="file" class="form-control-file pt-1 pl-2" id="image" name="image">
                        
                        <?php if($errors->has('image')): ?>
                            <strong><p class="text-danger"><?php echo e($errors->first('image')); ?></p></strong>
                        <?php endif; ?>

                    </div>
                    <div class="row pt-5 pl-3">
						<button class="btn btn-primary">Adicionar</button>
                    </div>
                </div>   
        </div>

    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projpag\simple_laravel\resources\views/galeria/create.blade.php ENDPATH**/ ?>