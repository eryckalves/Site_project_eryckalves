<?php $__env->startComponent('mail::message'); ?>


<div><p><strong>Nome:</strong> <?php echo e($data['name']); ?><p><div>
<div><p><strong>E-mail:</strong> <?php echo e($data['email']); ?><p><div>

<div><p><strong>Mensagem:</strong><p><div>

<div><p><?php echo e($data['message']); ?><p><div>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\projpag\simple_laravel\resources\views/emails/contato/contact-form.blade.php ENDPATH**/ ?>